# ISSEO Assistant

Application mobile IA pour la gestion des tâches ISSEO.

## Déploiement Railway

1. Créer un compte sur railway.app
2. "New Project" → "Deploy from GitHub repo"
3. Connecter ce repo
4. Ajouter la variable d'environnement : ANTHROPIC_API_KEY=votre_clé
5. Railway démarre automatiquement

## Variables d'environnement requises
- ANTHROPIC_API_KEY : votre clé API Anthropic
